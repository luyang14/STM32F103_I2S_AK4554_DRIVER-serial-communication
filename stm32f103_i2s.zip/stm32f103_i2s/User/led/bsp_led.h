#include "stm32f10x.h"
#include <stdio.h>

void Led_Init(void);

