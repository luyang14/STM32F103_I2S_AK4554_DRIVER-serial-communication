#ifndef __BSP_RELAY_H
#define	__BSP_RELAY_H

#include "stm32f10x.h"
#include <stdio.h>


void Relay_GPIO_Config(void);

#endif /* __BSP_INIT_H */
