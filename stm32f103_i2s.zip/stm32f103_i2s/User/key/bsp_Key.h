#ifndef	__KEY_h
#define	__KEY_h


#include "stm32f10x.h"

void KEY_GPIO_Init(void);
void BSP_TIM4_init(void);

extern char WIFI_Con_Flag;//wifi���ӱ�־

#endif


